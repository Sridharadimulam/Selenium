package com.qa.tms.utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.qa.tms.base.Testbase;
import com.qa.tms.pages.Homepage;

public class Baseextentreports {
	public ExtentHtmlReporter htmlreporter;
	public ExtentReports reports;
	public ExtentTest test;
	public Homepage h;
	public WebDriver dr;
	public Testbase t;
	 ObjInfo oInfo=new ObjInfo();
	@BeforeSuite
	public void setup(){
		htmlreporter=new ExtentHtmlReporter(System.getProperty("user.dir") +"/test-output/UnityReport.html");
	reports=new ExtentReports();
	reports.attachReporter(htmlreporter);
	
	htmlreporter.config().setChartVisibilityOnOpen(true);
htmlreporter.config().setDocumentTitle("techwave");	
htmlreporter.config().setReportName("sridhar");
htmlreporter.config().setTheme(Theme.DARK);	
htmlreporter.config().setTestViewChartLocation(ChartLocation.TOP);
	}
	
	@AfterMethod
	public void getResult(ITestResult result){
		if(result.getStatus()==ITestResult.SUCCESS){
			test.log(Status.PASS,MarkupHelper.createLabel(result.getName()+" Test Case PASSED", ExtentColor.GREEN));
		}
		 else
	        {
	            test.log(Status.SKIP, MarkupHelper.createLabel(result.getName()+" Test Case SKIPPED", ExtentColor.ORANGE));
	            test.skip(result.getThrowable());
	        }
	                }
	
	 @AfterSuite
	    public void tearDown() throws Exception
	    {
	                                reports.flush();
	                               
	                                System.setProperty("webdriver.chrome.driver", oInfo.DriverPath);
	                                dr=new ChromeDriver();
	                                dr.manage().window().maximize();
	                                dr.get(System.getProperty("user.dir") +"/test-output/UnityReport.html");
	                                                
	                                Thread.sleep(5000);
	                                
	    }
		
	}


