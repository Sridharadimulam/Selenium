package com.qa.tms.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.tms.base.Testbase;

public class Createprojectpage extends Testbase{
	public static Logger log=Logger.getLogger(Createprojectpage.class);
	@FindBy(xpath="//*[@id='Name']")
public static WebElement projectname ;
	public Createprojectpage(){
		PageFactory.initElements(dr, this);	
	}
	
	public void enterprojectdetails(){
		projectname.sendKeys("test");
		
	}
}
