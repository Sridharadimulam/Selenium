package com.qa.tms.testcases;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.qa.tms.base.Testbase;
import com.qa.tms.pages.Companysearchpage;
import com.qa.tms.pages.Createprojectpage;
import com.qa.tms.pages.Homepage;
import com.qa.tms.pages.Loginpage;
import com.qa.tms.pages.Projectspage;

public class Hometest extends Testbase{
	
	private static final Logger log=Logger.getLogger(Hometest.class.getName());

public Homepage h;
public WebDriver dr;
public Loginpage  l;
public Projectspage p;
public Companysearchpage c;
Createprojectpage cr;
	public Hometest() throws IOException {
		super();
	}
@BeforeTest
public void test1(){
	
	initialization();
	h=new Homepage();
	l=new Loginpage();
	p=new Projectspage();
	c=new Companysearchpage();
	cr=new Createprojectpage();
}
	@Test(priority=0)
	public void login(){
	h.login();
		test=reports.createTest("TC# 1 :: login is started"); 
		log.info("login is started");
	}
	@Test(priority=1)
	public void clickontile() throws InterruptedException{
	System.out.println("clickontile is started");
l.clickontilethebigwordtmstile();
//Thread.sleep(2000);
		test=reports.createTest("TC# 2 :: clickontile");
		log.info("clickontile");
	}
	
	@Test(priority=2)
	public void createproject() throws InterruptedException {
		System.out.println("createproject is started");
          p.createproject();
		  test=reports.createTest("TC# 3 :: createproject");
			log.info("createproject");
	}
	@Test(priority=3)
	public void searchcompany() throws InterruptedException {
		//System.out.println("searchcompany");
          c.search();
		  test=reports.createTest("TC# 4 :: searchcompany"); 
		  log.info("searchcompany");
	}
	
	@Test(priority=4)
	public void createprojectfortest(){
		System.out.println("createprojectfortest1");
		cr.enterprojectdetails();
		test=reports.createTest("TC# 5 :: createprojectfortest1");
		 log.info("createprojectfortest1");
	}
}
