package runningfailedtestcases;

import org.testng.Assert;
import org.testng.annotations.Test;

public class test1 {
	@Test
	public void testhard1(){
		
		System.out.println("testhard1 started");
		Assert.assertTrue(true);
		System.out.println("testhard1 completed");
		
	}
}
