package runningfailedtestcases;


import static org.testng.Assert.assertFalse;

import org.testng.Assert;
import org.testng.annotations.Test;

public class test2 {
	@Test
	public void testhard2(){
		
		System.out.println("testhard2 started");
		Assert.assertTrue(false);
		System.out.println("testhard2 completed");
		
	}
}
