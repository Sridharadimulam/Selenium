package runningfailedtestcases;

import org.testng.Assert;
import org.testng.annotations.Test;

public class test3 {
	@Test
	public void testhard3(){
		
		System.out.println("testhard3 started");
		Assert.assertTrue(true);
		System.out.println("testhard3 completed");
		
	}
}
