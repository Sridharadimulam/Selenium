package Retrytest;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class Retryanalyzer implements IRetryAnalyzer {
int count=0;
int retrylimit=3;
	public boolean retry(ITestResult result) {
		// TODO Auto-generated method stub
		
		if(count<retrylimit){
			count++;
			return true;
		}
		return false;
	}

}
