package first;

import org.testng.annotations.Test;

public class methodinclude {
@Test(groups={"sanity-group"},priority=3)
	
	public void firsttest1(){
		long threadid=Thread.currentThread().getId();
		System.out.println("firsttest1"+"with threadid is:"+threadid);
	
	}
	@Test(groups={"sanity-group"},priority=2)
	public void firsttest3(){
		long threadid=Thread.currentThread().getId();
		System.out.println("firsttest3"+"with threadid is:"+threadid);
	}
	@Test(groups={"sanity-group","regression-group"},priority=1)
	public void firsttest2(){
		long threadid=Thread.currentThread().getId();
		System.out.println("firsttest2"+"with threadid is:"+threadid);
	}
}
