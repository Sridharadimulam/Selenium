package first;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class secondclasss {
	@BeforeMethod
	public void beforesecondmethod(){
		System.out.println("beforesecondmethod");
	}
	
	@Test
	public void secondtest1(){
		System.out.println("secondtest1");
	}
	@Test
	public void secondtest2(){
		System.out.println("secondtest2");
	}
	@AfterMethod
	public void AfterMethodsecondmethod(){
		System.out.println("AfterMethodsecondmethod");
	}
	
}
