package first;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class firstclass {

	@BeforeMethod
	public void beforefirstmethod(){
		System.out.println("beforefirstmethod");
	}
	@Test(groups={"sanity=group"})
	public void firsttest1(){
		System.out.println("firsttest1");
	}
	@Test(groups={"sanity=group"})
	public void firsttest3(){
		System.out.println("firsttest3");
	}
	@Test
	public void firsttest2(){
		System.out.println("firsttest2");
	}
	@AfterMethod
	public void AfterMethodfirstmethod(){
		System.out.println("AfterMethodfirstmethod");
	}
	
}
