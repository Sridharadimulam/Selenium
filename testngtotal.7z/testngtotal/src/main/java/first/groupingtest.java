package first;

import org.testng.annotations.Test;

public class groupingtest {

	
	@Test(groups={"sanity-group"})
	public void firsttest1(){
		System.out.println("firsttest1");
	}
	@Test(groups={"sanity-group"})
	public void firsttest3(){
		System.out.println("firsttest3");
	}
	@Test(groups={"sanity-group","regression-group"})
	public void firsttest2(){
		System.out.println("firsttest2 ssanity and regression");
	}
	
	
}
