package listenerstest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
@Listeners(listenerstest.Testnglistners.class)
public class Testcaseforlistener {
public WebDriver dr;

	@Test
	public void test1(){
		dr=new ChromeDriver();
		dr.get("https://sonnysdirect.com");
		dr.manage().window().maximize();
		String s=dr.getTitle();
		dr.quit();
	}
	@Test
	public void test2(){
		dr=new ChromeDriver();
		dr.get("https://sonnysdirect.com");
		dr.manage().window().maximize();
		String s=dr.getTitle();
		dr.quit();
	}
}
