package Webdrivertestngtests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class hardassertiontest {
WebDriver dr;
	String acttitle="Car Wash Equipment Supplier | Sonny’s The CarWash Factory";
	String acttitle1="Car Wash Equipment Supplier | Sonny’s The CarWash Factor";
	
	@Test
	public void launch(){
		dr=new  ChromeDriver();
		System.out.println("launch started");
		dr.get("https://sonnysdirect.com");
		dr.manage().window().maximize();
		String title=dr.getTitle();
		System.out.println(title);
Assert.assertEquals(acttitle, title,"test1");
System.out.println("launch completed");
dr.quit();
	}
	@Test
	public void launch1(){
		dr=new  ChromeDriver();
		System.out.println("launch1 started");
		dr.get("https://sonnysdirect.com");
		dr.manage().window().maximize();
		String title=dr.getTitle();
		System.out.println(title);
Assert.assertEquals(acttitle1, title,"test1");	
System.out.println("launch1 completed");
dr.quit();
	}
}
