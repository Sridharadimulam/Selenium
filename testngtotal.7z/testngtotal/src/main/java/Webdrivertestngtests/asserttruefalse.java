package Webdrivertestngtests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class asserttruefalse {
	String s="hello sridhar";
	
	@Test
	public void test(){
		
		Assert.assertTrue(s.contains("sridghar"),"s does not contain 'sridghar'");
	}
	@Test
	public void test1(){
		
		Assert.assertTrue(s.contains("sridhar"),"s  contain 'sridhar'for test1");
	}
	@Test
	public void test2(){
		
		Assert.assertFalse(s.contains("sridhar"),"s contain 'sridhar' for test2");
	}
	@Test
	public void test3(){
		
		Assert.assertFalse(s.contains("srigdhar"),"s does not contain 'sridhar'");
	}
}
