package Webdrivertestngtests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Assertequaltest {
	
	
	WebDriver dr;
	
	String acttitle="Car Wash Equipment Supplier | Sonny’s The CarWash Factory";
	@Test
	public void launch(){
		dr=new  ChromeDriver();
		dr.get("https://sonnysdirect.com");
		dr.manage().window().maximize();
		String title=dr.getTitle();
		System.out.println(title);
Assert.assertEquals(acttitle, title);		
	
dr.quit();
	}
	@Test
	public void launch1(){
		dr=new  ChromeDriver();
		dr.get("https://sonnysdirect.com");
		dr.manage().window().maximize();
		String title=dr.getTitle();
		System.out.println(title);
Assert.assertEquals(acttitle, title,"does not match title");		
dr.quit();
	}
	@Test
	public void launch2(){
		dr=new  ChromeDriver();
		dr.get("https://sonnysdirect.com");
		dr.manage().window().maximize();
		String title=dr.getTitle();
		System.out.println(title);
Assert.assertNotEquals(acttitle, title,"assertion is matched so it is false and throwing assertion error");		
dr.quit();
	}
		
	@Test
	public void launch3(){
		dr=new  ChromeDriver();
		dr.get("https://sonnysdirect.com");
		dr.manage().window().maximize();
		String title=dr.getTitle();
		System.out.println(title);
Assert.assertNotEquals(acttitle, title,"match title");		
dr.quit();
	}
}
