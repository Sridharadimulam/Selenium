package Webdrivertestngtests;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class softassertiontest {
	String s="hello sridhar";
	@Test
	public void testsoft(){
		SoftAssert sa=new SoftAssert();
		System.out.println("testsoft started");
		sa.assertTrue(s.contains("sridhhar"),"s does not contain 'sridghar'");
		System.out.println("testsoft completed");
		sa.assertAll();
	}
	@Test
	public void testhard(){
		
		System.out.println("testhard started");
		Assert.assertTrue(s.contains("sridhhar"),"s does not contain 'sridghar'");
		System.out.println("testhard completed");
		
	}
}
