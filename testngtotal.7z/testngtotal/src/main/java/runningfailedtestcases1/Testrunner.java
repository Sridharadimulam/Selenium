package runningfailedtestcases1;

import java.util.ArrayList;
import java.util.List;

import org.testng.TestNG;

public class Testrunner {

	public static void main(String[] args) {
		TestNG runner=new TestNG();
		List<String>list=new ArrayList<String>();
		//add the failed test cases xml under test output folder.
		list.add("E:\\testworkspace1\\testngtotal\\test-output\\failedtestsuit\\testng-failed.xml");
		runner.setTestSuites(list);
		runner.run();
	}

}
