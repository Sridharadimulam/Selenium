package paramerterizationtest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class crossbrowserparameterixationtest {
public WebDriver dr;
	@Test
	@Parameters("browser")
	public void cbtest(String browsername){
		if(browsername.equalsIgnoreCase("chrome")){
			dr=new ChromeDriver();
			
		}else if(browsername.equalsIgnoreCase("firefox")){
			System.out.println("firefox");
		
		}else{
			System.out.println("ie");
		}
		
/*		dr.get("https://sonnysdirect.com");	
dr.manage().window().maximize();*/

	}}
