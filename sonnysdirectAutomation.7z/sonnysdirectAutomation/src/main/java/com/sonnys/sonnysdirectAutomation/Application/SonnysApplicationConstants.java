package com.sonnys.sonnysdirectAutomation.Application;

public class SonnysApplicationConstants {
public static final String SEARCHPRODUCT_SHEET="SearchProduct";
public static final String SELECTPRODUCT_SHEET="SelectProduct";
public static final String ADDPRODUCT_SHEET="AddProduct";
public static final String VIEWBASKET_SHEET="ViewBasket";
public static final String SIGNIN_SHEET="Signin";
public static final String MANAGECART_SHEET="ManageCart";
public static final String SELECTDELIVERYMODE_SHEET="SelectDeliveryMode";
public static final String DELIVERY_SHEET="Delivery";
public static final String PAYMENT_SHEET="Payment";
public static final String PAYMENTOPTIONS_SHEET="PaymentOptions";
public static final String CONFIRMATION_SHEET="Confirmation";
public static final String LOGOUT_SHEET="Logout";
public static final String LAUNCHAPPLICATION_SHEET="LaunchApplication";
public static final String ONLINEPAYEMENT_SHEET="OnlinePayment";
public static final String EXPRESSCHECKOUT_SHEET="Expresscheckout";
public static final String CHECKOUT_SHEET="Checkout";
public static final String REGISTER_SHEET="Register";
public static final String ADDRESSBOOK_SHEET="AddressBook";
public static final String PAYMENTWITHSAVEDCARD_SHEET="Paymentwithsavedcard";


public static final String ACTION_CHECKOUT="Checkout";
public static final String ACTION_ADDRESSBOOK="ADDRESSBOOK";
public static final String ACTION_SEARCH="Search";
public static final String ACTION_SELECT="Select";
public static final String ACTION_ADDTOCART="AddToCart";
public static final String ACTION_VIEWBASKET="ViewBasket";
public static final String ACTION_SIGNIN="Signin";
public static final String ACTION_MANAGECART="ManageCart";
public static final String ACTION_SELECTDELIVERYMODE="SelectDeliveryMode";
public static final String ACTION_DELIVERY="Delivery";
public static final String ACTION_PAYMENT="Payment";
public static final String ACTION_PAYMENTOPTIONS="PaymentOptions";
public static final String ACTION_CONFIRMATION="Confirmation";
public static final String ACTION_LOGOUT="Logout";
public static final String ACTION_LAUNCH = "Launch";
public static final String ACTION_SAVEDPAYMENTPAYMENT="SAVEDPAYMENTPAYMENT";



}
