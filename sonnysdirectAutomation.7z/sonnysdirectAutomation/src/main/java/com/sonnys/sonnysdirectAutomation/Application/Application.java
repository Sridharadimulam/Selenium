package com.sonnys.sonnysdirectAutomation.Application;


import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;

import com.sonnys.sonnysdirectAutomation.common.utils.PropertyLoader;
import com.sonnys.sonnysdirectAutomation.common.utils.TestException;



public class Application {
	private static final Logger logger = Logger.getLogger(Application.class.getSimpleName());

	protected static final String BROWSER = "BROWSER";
	protected static final String CAPABILITIES = "CAPABILITIES";
	protected static final String DRIVERSPATH = "DRIVERSPATH";
	protected static final String URL = "URL";
	protected static final String PRODUCTID = "PRODUCTID";
	protected static final String PRODUCTNAME="PRODUCTNAME";
	protected static final String EXPECTEDMESSAGE = "EXPECTEDMESSAGE";
	protected static final String UPDATEQTY = "UPDATEQTY";
	protected static final String CONFIRMATIONMESSAGE = "CONFIRMATIONMESSAGE";
	protected static final String GIFTBOX = "GIFTBOX";
	protected static final String EMAIL = "EMAIL";
	protected static final String FIRSTNAME = "FIRSTNAME";
	protected static final String LASTNAME = "LASTNAME";;
	protected static final String PAYMENTTYPE = "PAYMENTTYPE";
	protected static final String CARDTYPE = "CARDTYPE";
	protected static final String CARDNUMBER = "CARDNUMBER";
	protected static final String SECURITYCODE = "SECURITYCODE";
	protected static final String ADDRESS = "ADDRESS";
	protected static final String THANKYOUMESSAGE = "THANKYOUMESSAGE";
	protected static final String ORDERNUMBERMESSAGE = "ORDERNUMBERMESSAGE";
	protected static final String UPDATEGRT = "UPDATEGRT";

	protected static final String  PO="PURCHAGEORDERNUMBER";
	protected static final String Paymenttype="PAYMENTTYPE";
	protected static final String Nameoncard="NAMEONCARD";
	protected static final String Cardnumber="CARDNUMBER";
	protected static final String cardverificationnumber="CARDVERIFICATIONNUMBER";
	protected static final String  Expirymonth="EXPIRYMONTH";
	protected static final String  Expiryyear="EXPIRYYEAR";
	

	protected static final String AMEX="AMEX";
	protected static final String DISCOVER="DISCOVER";
	protected static final String VISA="VISA";
	protected static final String MASTERCARD="MASTERCARD";
	
	protected static final String XPATH_ROOT = "/html/body";
	protected static final String DELIVERYTYPE = "DELIVERYTYPE";

	protected static final String EMAIL1="EMAIL";

	protected static final String PASSWORD ="PASSWORD";
	/**
	 * Map that contains data that are saved while executing scenarios Saved
	 * data in this map are used later
	 */
	private static Map<String, String> mapOutParams = new HashMap<String, String>();

	/**
	 * Map loaded with excel sheet data @ start of each TestCase
	 */
	protected Map<String, String> mapInputParameters = new HashMap<String, String>();

	/**
	 * Handler that handles all JSF components
	 */
	protected SonnysSeleniumHandler sonnysSeleniumHandler;

	protected static PropertyLoader objectMap;

	/**
	 * sets ATG Selenium Handler
	 * 
	 * @param jsfHandler
	 */
	public void setSonnysSeleniumHandler(SonnysSeleniumHandler sonnysSeleniumHandler) {
		this.sonnysSeleniumHandler = sonnysSeleniumHandler;
	}

	/**
	 * return JSFSeleniumHandler
	 * 
	 * @return
	 */
	public SonnysSeleniumHandler getSonnysSeleniumHandler() {
		return this.sonnysSeleniumHandler;
	}

	public PropertyLoader getObjectMap() {
		return objectMap;
	}

	public void setObjectMap(PropertyLoader objectMap) {
		this.objectMap = objectMap;
	}

	/**
	 * Setting Map with excel sheet data required for test case
	 * 
	 * @param inMap
	 */
	public void setMapInputParameters(Map<String, String> inMap) {
		this.mapInputParameters = inMap;
	}

	protected String getParameter(Map<String, String> pmapArguments, String key) {
		return ((pmapArguments.get(key) == null) ? "" : pmapArguments.get(key));
	}

	protected void saveParameter(String key, String value) {
		mapOutParams.put(key, value);
	}

	protected void appendParameter(String key, String value) {
		if (StringUtils.isBlank(value)) {
			return;
		}
		if (mapOutParams.containsKey(key)) {
			value = mapOutParams.get(key) + "," + value;
		}
		mapOutParams.put(key, value);
	}

	protected String getParameter(String key) {
		String result = "";
		if (mapOutParams.containsKey(key)) {
			result = mapOutParams.get(key);
		}
		return result;
	}

	protected void assertNotNull(String value, String message) throws TestException {
		if (StringUtils.isBlank(value)) {
			String filePath = sonnysSeleniumHandler.captureScreenShoot();
			//logger.error(message + " is Null");
			throw new TestException(message + ", please find the snapshot attached at location ", filePath);
		}
		//logger.debug(message + " is " + value);

	}

	protected void assertValue(String expectedValue, String actualValue, String field) throws TestException {
		if (StringUtils.isNotBlank(expectedValue)) {
			if (!expectedValue.equalsIgnoreCase(actualValue)) {
				String filePath = sonnysSeleniumHandler.captureScreenShoot();
				throw new TestException("expected value of " + field + " is---->" + expectedValue
						+ "  but actual value  is " + actualValue + ", please find the snapshot attached at location ",
						filePath);
			}
			logger.info("expected value and actual value of field " + field + " are " + actualValue);
		}
	}

	protected void assertContains(String expectedValue, String actualValue, String field) throws TestException {
		if (StringUtils.isNotBlank(expectedValue)) {
			String expected = expectedValue.toUpperCase();
			String actual = actualValue.toUpperCase();
			if (!actual.contains(expected)) {
				String filePath = sonnysSeleniumHandler.captureScreenShoot();
				throw new TestException("expected value of " + field + " is---->" + expectedValue
						+ "  but actual value  is " + actualValue + ", please find the snapshot attached at location ",
						filePath);
			}
			logger.info("expected value and actual value of field " + field + " are " + expectedValue);
		}
	}

	/**
	 * Used to clear the Map(OutMap) @ end of every execution;
	 */
	protected void clearMaps() {
		mapOutParams.clear();
		mapInputParameters.clear();
	}

	public void tearDown() {
		clearMaps();
		sonnysSeleniumHandler.tearDown();

	}


}
