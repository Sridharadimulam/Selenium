package com.sonnys.sonnysdirectAutomation.Application;



import com.sonnys.sonnysdirectAutomation.common.utils.TestException;
import com.sonnys.sonnysdirectAutomation.webdriver.utils.WebDriverConstants;

public class Signin  extends Application{
private static final String PROPERTY_Signin_XPATH="signinlink";
private static final String PROPERTY_EMAILID="usernameid";
private static final String PROPERTY_PasswordID="passwordid";
private static final String PROPERTY_signinbutton="signinbutton";
	
	//private static final String PROPERTY_BUTTON_SEARCHSUBMIT="BUTTON_SEARCHSUBMITXPATH";
	
	
	public void execute() throws TestException {
		String username = getParameter(mapInputParameters,EMAIL1);
		String Password = getParameter(mapInputParameters,PASSWORD);
		sonnysSeleniumHandler.jsClick(WebDriverConstants.Locators.XPATH, objectMap.getTestProperty(PROPERTY_Signin_XPATH), "PROPERTY_Signin_XPATH");
	sonnysSeleniumHandler.waitForAjaxToLoad();
	sonnysSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.ID, objectMap.getTestProperty(PROPERTY_EMAILID), username, username);
	sonnysSeleniumHandler.waitForAjaxToLoad();
	sonnysSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.ID, objectMap.getTestProperty(PROPERTY_PasswordID), Password, Password);
	sonnysSeleniumHandler.waitForAjaxToLoad();
	sonnysSeleniumHandler.jsClick(WebDriverConstants.Locators.XPATH, objectMap.getTestProperty(PROPERTY_signinbutton), "signinbutton");
	sonnysSeleniumHandler.waitForAjaxToLoad(); 
	}
	

}
