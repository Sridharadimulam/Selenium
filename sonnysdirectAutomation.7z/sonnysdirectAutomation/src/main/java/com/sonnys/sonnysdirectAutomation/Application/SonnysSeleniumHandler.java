package com.sonnys.sonnysdirectAutomation.Application;

import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.sonnys.sonnysdirectAutomation.common.utils.TestException;
import com.sonnys.sonnysdirectAutomation.testdefinitions.TestConstants;
import com.sonnys.sonnysdirectAutomation.webdriver.utils.SeleniumHandler;
import com.sonnys.sonnysdirectAutomation.webdriver.utils.WebDriverConstants;



public class SonnysSeleniumHandler extends SeleniumHandler {
	private static final Logger logger = Logger.getLogger(SonnysSeleniumHandler.class.getSimpleName());
	private final String JS_JQUERY_DEFINED = "return typeof window.jQuery != 'undefined';";
	private final String JS_JQUERY_INACTIVE = "return window.jQuery.active == 0;";
	private  final String JS_DOCUMENT_READY = "return document.readyState == 'complete';";
	
	/**
	 * used to initialize selenium driver
	 * 
	 * @param pstrBrowser
	 *            browser Name
	 * @param pDesiredCapabilities
	 *            desired capabilities of the browser
	 * @param pstrDriversPath
	 *            driver path
	 * @throws TestException
	 */
	public SonnysSeleniumHandler() throws TestException {
		String browser = System.getProperty(TestConstants.SystemProperty.BROWSER);
		String capabilities = System.getProperty(TestConstants.SystemProperty.CAPABILITIES);
		String driverPath = System.getProperty(TestConstants.SystemProperty.DRIVERSPATH);
		if (isWindows()) {
			initWindows(browser, capabilities, driverPath);
		} else {
			initUnix(browser, capabilities, driverPath);
		}

	}


	/**
	 * methods waits for all the jquerys and primefaces events to get completed
	 * 
	 * @throws TestException
	 */
	public void waitForAjaxToLoad() throws TestException {
		boolean ajaxLoaded;		
		int totalAttempts = WebDriverConstants.Time.WAIT_TIME;
		int attempt = 0;
		do {
			ajaxLoaded = true;
			wait(WebDriverConstants.Time.POLLING_TIME);			
			boolean jQueryDefined = executeBooleanJavascript(JS_JQUERY_DEFINED);
			boolean documentReady =executeBooleanJavascript(JS_DOCUMENT_READY);
			if (jQueryDefined) {
				ajaxLoaded &= executeBooleanJavascript(JS_JQUERY_INACTIVE);
			}
			if (ajaxLoaded && documentReady) {
				break;
			}
			
			attempt = attempt + 1;
		} while (attempt < totalAttempts);
		if (!ajaxLoaded) {
			String filePath = captureScreenShoot();
			logger.error("ajax not loaded on page even after wating for " + totalAttempts + " seconds");
			throw new TestException("ajax not loaded on page even after wating for " + totalAttempts
					+ " seconds, please find the snapshot at location ", filePath);
		}
	
	}

	public void tearDown(){
		super.tearDown();
	}

	@Override
	public void setBrowser() {
		browser = System.getProperty(TestConstants.SystemProperty.BROWSER);
		
	}

	@Override
	public void setDesiredCapabilities() {
		desiredCapabilities = System.getProperty(TestConstants.SystemProperty.CAPABILITIES);
		
	}

	@Override
	public void setDriversPath() {
		driverPath = System.getProperty(TestConstants.SystemProperty.DRIVERSPATH);
		
	}

	@Override
	public void setUrl() {
		driverPath = System.getProperty(TestConstants.SystemProperty.URL);
		
	}


	public void get(String url) {
		// TODO Auto-generated method stub
		
	}


	public List<WebElement> findElements(By by) {
		// TODO Auto-generated method stub
		return null;
	}


	public WebElement findElement(By by) {
		// TODO Auto-generated method stub
		return null;
	}


	public String getPageSource() {
		// TODO Auto-generated method stub
		return null;
	}


	public void close() {
		// TODO Auto-generated method stub
		
	}


	public void quit() {
		// TODO Auto-generated method stub
		
	}


	public Set<String> getWindowHandles() {
		// TODO Auto-generated method stub
		return null;
	}


	public String getWindowHandle() {
		// TODO Auto-generated method stub
		return null;
	}





	






	
}
