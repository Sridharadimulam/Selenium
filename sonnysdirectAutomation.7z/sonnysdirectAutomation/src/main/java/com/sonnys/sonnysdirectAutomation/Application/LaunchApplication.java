package com.sonnys.sonnysdirectAutomation.Application;

import com.sonnys.sonnysdirectAutomation.common.utils.TestException;

public class LaunchApplication extends Application{
	
	public void execute() throws TestException {
		sonnysSeleniumHandler.open();
		sonnysSeleniumHandler.waitForAjaxToLoad();
		
	}
}
