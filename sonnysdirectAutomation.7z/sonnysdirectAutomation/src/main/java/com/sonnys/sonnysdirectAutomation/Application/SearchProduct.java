package com.sonnys.sonnysdirectAutomation.Application;

import com.sonnys.sonnysdirectAutomation.common.utils.TestException;
import com.sonnys.sonnysdirectAutomation.webdriver.utils.WebDriverConstants;


public class SearchProduct extends Application{
	private static final String PROPERTY_TEXTBOX_SEARCHINPUT="TEXTBOX_SEARCHINPUT";
	private static final String PROPERTY_BUTTON_SEARCHSUBMIT="BUTTON_SEARCHSUBMIT";
	
	
	public void execute() throws TestException {
		String productID = getParameter(mapInputParameters,PRODUCTID);
		
		sonnysSeleniumHandler.waitForAjaxToLoad();
		sonnysSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.ID, 
			                          	objectMap.getTestProperty(PROPERTY_TEXTBOX_SEARCHINPUT), productID, "Search Product");
		sonnysSeleniumHandler.jsClick(WebDriverConstants.Locators.XPATH,
				                  objectMap.getTestProperty(PROPERTY_BUTTON_SEARCHSUBMIT), "Search Submit");
		
	}}