package com.sonnys.sonnysdirectAutomation.webdriver.utils;

public interface Handler {

	void setBrowser();

	void setDesiredCapabilities();

	void setDriversPath();

	void setUrl();

}
