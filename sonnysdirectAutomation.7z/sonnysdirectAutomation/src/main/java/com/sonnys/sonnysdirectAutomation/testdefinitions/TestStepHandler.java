package com.sonnys.sonnysdirectAutomation.testdefinitions;


import java.util.Map;
import java.util.logging.Logger;

import com.sonnys.sonnysdirectAutomation.Application.AddProduct;
import com.sonnys.sonnysdirectAutomation.Application.Application;
import com.sonnys.sonnysdirectAutomation.Application.Checkout;
import com.sonnys.sonnysdirectAutomation.Application.LaunchApplication;
import com.sonnys.sonnysdirectAutomation.Application.Paymentwithsavedcard;
import com.sonnys.sonnysdirectAutomation.Application.SearchProduct;
import com.sonnys.sonnysdirectAutomation.Application.SelectAddress;
import com.sonnys.sonnysdirectAutomation.Application.SelectPaymentcard;
import com.sonnys.sonnysdirectAutomation.Application.SelectProduct;
import com.sonnys.sonnysdirectAutomation.Application.Signin;
import com.sonnys.sonnysdirectAutomation.Application.SonnysApplicationConstants;
import com.sonnys.sonnysdirectAutomation.common.utils.TestException;



public class TestStepHandler {

	private static final Logger logger = Logger.getLogger(TestSuite.class.getSimpleName());
	private Application sonnysApplication;
	private TestStepDefinition testStep;

	/**
	 * Constructor ; Initializes WSPublishing & TestStepDefinition
	 * 
	 * @param wsPublishing
	 * @param testStep
	 */
	public TestStepHandler(Application sonnysApplication, TestStepDefinition testStep) {
		super();
		this.sonnysApplication = sonnysApplication;
		this.testStep = testStep;
	}


	
	private void handlerLaunchApplication() throws TestException {
		String strAction = testStep.getAction().trim();
		Map<String, String> mapArguments = testStep.getMapArguments();
		LaunchApplication launch = new LaunchApplication();
		launch.setSonnysSeleniumHandler(sonnysApplication.getSonnysSeleniumHandler());
		launch.setObjectMap(sonnysApplication.getObjectMap());
		launch.setMapInputParameters(mapArguments);
		if (SonnysApplicationConstants.ACTION_LAUNCH.equalsIgnoreCase(strAction)) {
			launch.execute();
			
		}

	}
	
	private void handlersearchforproduct() throws TestException {
		String strAction = testStep.getAction().trim();
		Map<String, String> mapArguments = testStep.getMapArguments();
		SearchProduct search = new SearchProduct();
		search.setSonnysSeleniumHandler(sonnysApplication.getSonnysSeleniumHandler());
		search.setObjectMap(sonnysApplication.getObjectMap());
		search.setMapInputParameters(mapArguments);
		if (SonnysApplicationConstants.ACTION_SEARCH.equalsIgnoreCase(strAction)) {
			search.execute();
		}

	}
	
	private void handlersignin() throws TestException {
		String strAction = testStep.getAction().trim();
		Map<String, String> mapArguments = testStep.getMapArguments();
		Signin signin = new Signin();
		signin.setSonnysSeleniumHandler(sonnysApplication.getSonnysSeleniumHandler());
		signin.setObjectMap(sonnysApplication.getObjectMap());
		signin.setMapInputParameters(mapArguments);
		if (SonnysApplicationConstants.ACTION_SIGNIN.equalsIgnoreCase(strAction)) {
			signin.execute();
		}

	}

	private void handlerselectproduct() throws TestException {
		String strAction = testStep.getAction().trim();
		Map<String, String> mapArguments = testStep.getMapArguments();
		SelectProduct select = new SelectProduct();
		select.setSonnysSeleniumHandler(sonnysApplication.getSonnysSeleniumHandler());
		select.setObjectMap(sonnysApplication.getObjectMap());
		select.setMapInputParameters(mapArguments);
		if (SonnysApplicationConstants.ACTION_SELECT.equalsIgnoreCase(strAction)) {
			select.execute();
		}

	}
	
	private void handlerAddProduct() throws TestException {
		String strAction = testStep.getAction().trim();
		Map<String, String> mapArguments = testStep.getMapArguments();
		AddProduct addproduct = new AddProduct();
		addproduct.setSonnysSeleniumHandler(sonnysApplication.getSonnysSeleniumHandler());
		addproduct.setObjectMap(sonnysApplication.getObjectMap());
		addproduct.setMapInputParameters(mapArguments);
		if (SonnysApplicationConstants.ACTION_ADDTOCART.equalsIgnoreCase(strAction)) {
			addproduct.execute();
		}

	}
	
	
	private void handlercheckout() throws TestException {
		String strAction = testStep.getAction().trim();
		Map<String, String> mapArguments = testStep.getMapArguments();
		Checkout checkout = new Checkout();
		checkout.setSonnysSeleniumHandler(sonnysApplication.getSonnysSeleniumHandler());
		checkout.setObjectMap(sonnysApplication.getObjectMap());
		checkout.setMapInputParameters(mapArguments);
		if (SonnysApplicationConstants.ACTION_CHECKOUT.equalsIgnoreCase(strAction)) {
			checkout.execute();
		}

	}
	
	
	private void handlerSelectAddress() throws TestException {
		String strAction = testStep.getAction().trim();
		Map<String, String> mapArguments = testStep.getMapArguments();
		SelectAddress selectaddress = new SelectAddress();
		selectaddress.setSonnysSeleniumHandler(sonnysApplication.getSonnysSeleniumHandler());
		selectaddress.setObjectMap(sonnysApplication.getObjectMap());
		selectaddress.setMapInputParameters(mapArguments);
		if (SonnysApplicationConstants.ACTION_ADDRESSBOOK.equalsIgnoreCase(strAction)) {
			selectaddress.execute();
		}

	}
	
	
	private void handlerSelectPaymentcard() throws TestException {
		String strAction = testStep.getAction().trim();
		Map<String, String> mapArguments = testStep.getMapArguments();
		SelectPaymentcard selectsaymentcard = new SelectPaymentcard();
		selectsaymentcard.setSonnysSeleniumHandler(sonnysApplication.getSonnysSeleniumHandler());
		selectsaymentcard.setObjectMap(sonnysApplication.getObjectMap());
		selectsaymentcard.setMapInputParameters(mapArguments);
		if (SonnysApplicationConstants.ACTION_PAYMENT.equalsIgnoreCase(strAction)) {
			selectsaymentcard.execute();
		}

	}
	
	
	private void handlerPaymentwithsavedcard() throws TestException {
		String strAction = testStep.getAction().trim();
		Map<String, String> mapArguments = testStep.getMapArguments();
		Paymentwithsavedcard paymentwithsavedcard = new Paymentwithsavedcard();
		paymentwithsavedcard.setSonnysSeleniumHandler(sonnysApplication.getSonnysSeleniumHandler());
		paymentwithsavedcard.setObjectMap(sonnysApplication.getObjectMap());
		paymentwithsavedcard.setMapInputParameters(mapArguments);
		if (SonnysApplicationConstants.ACTION_SAVEDPAYMENTPAYMENT.equalsIgnoreCase(strAction)) {
			paymentwithsavedcard.execute();
		}

	}
	/**
	 * Maps the Input sheet data to the corresponding handlers
	 * 
	 * @throws TestException
	 */
	public void handle() throws TestException {
		String sheetname = testStep.getSheetName();
		if (sheetname.equalsIgnoreCase(SonnysApplicationConstants.LAUNCHAPPLICATION_SHEET)) {
			handlerLaunchApplication();
		}else if(sheetname.equalsIgnoreCase(SonnysApplicationConstants.SEARCHPRODUCT_SHEET)) {
			handlersearchforproduct();	
		}else if(sheetname.equalsIgnoreCase(SonnysApplicationConstants.SIGNIN_SHEET)) {
			handlersignin();	
		}else if(sheetname.equalsIgnoreCase(SonnysApplicationConstants.SELECTPRODUCT_SHEET)) {
			handlerselectproduct();	
		}
		else if(sheetname.equalsIgnoreCase(SonnysApplicationConstants.ADDPRODUCT_SHEET)) {
			handlerAddProduct();	
		}else if(sheetname.equalsIgnoreCase(SonnysApplicationConstants.CHECKOUT_SHEET)) {
			handlercheckout();	
		}
		else if(sheetname.equalsIgnoreCase(SonnysApplicationConstants.ADDRESSBOOK_SHEET)) {
			handlerSelectAddress();	
		}else if(sheetname.equalsIgnoreCase(SonnysApplicationConstants.PAYMENT_SHEET)) {
			handlerSelectPaymentcard();	
		}else if(sheetname.equalsIgnoreCase(SonnysApplicationConstants.PAYMENTWITHSAVEDCARD_SHEET)) {
			handlerPaymentwithsavedcard();	
		}
		else
		{
			//logger.error("Invalid test data sheet name " + sheetname + ",please check your test data file");
			throw new TestException("Invalid test data sheet name " + sheetname + ",please check your test data file");
		}
	}

}
