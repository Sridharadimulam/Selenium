package com.sonnys.sonnysdirectAutomation.Application;

import com.sonnys.sonnysdirectAutomation.common.utils.TestException;
import com.sonnys.sonnysdirectAutomation.webdriver.utils.WebDriverConstants;

public class SelectProduct extends Application {

	private static final String PROPERTY_SELECTPRODUCT = "selectproduct";
	//private static final String PROPERTY_XPATH_HTMLTAG_LINK_PRODUCTTEXT = "XPATH_HTMLTAG_LINK_PRODUCTTEXT";
	

	/**
	 * 
	 * @param mapInputParameters
	 * @throws TestException
	 */
	public void execute() throws TestException {

		String productName = getParameter(mapInputParameters,PRODUCTNAME );
		sonnysSeleniumHandler.waitForAjaxToLoad();
		/*sonnysSeleniumHandler.jsClick(WebDriverConstants.Locators.XPATH,
				objectMap.getTestProperty(PROPERTY_SELECTPRODUCT), productName);*/
				
		
		sonnysSeleniumHandler.jsClick(WebDriverConstants.Locators.LINKTEXT,objectMap.getTestProperty(PROPERTY_SELECTPRODUCT), productName);
		
	}
}