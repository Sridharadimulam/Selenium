package com.sonnys.sonnysdirectAutomation.Application;

import org.apache.log4j.Logger;

import com.sonnys.sonnysdirectAutomation.common.utils.TestException;
import com.sonnys.sonnysdirectAutomation.webdriver.utils.WebDriverConstants;

public class SelectPaymentcard extends Application {
	private static final String PROPERTY_PONUMBERID="PONUMBERID";
	private static final String PROPERTY_NAMEONCARDID="NAMEONCARDID";
	private static final String PROPERTY_CARDNUMBERXPATH="CARDNUMBERXPATH";
	private static final String PROPERTY_SAVEPAYMENTMETHODID="SAVEPAYMENTMETHODID";
	
	private static final String PROPERTY_EXPIRYMONTHID="EXPIRYMONTHID";
	private static final String PROPERTY_EXPIRYYEARID="EXPIRYYEARID";
	private static final String PROPERTY_CARDCVVID="CARDCVVID";
	
	private static final Logger logger = Logger.getLogger(AddProduct.class.getSimpleName());
	public void execute() throws TestException {		
/*		String PaymenttypeAMEX=getParameter(mapInputParameters, AMEX);
	 	String PaymenttypeDISCOVER=getParameter(mapInputParameters,DISCOVER);
      	String PaymenttypeVISA=getParameter(mapInputParameters,VISA);
	    String PaymenttypeMASTERCARD=getParameter(mapInputParameters,MASTERCARD);
		
		if(PaymenttypeAMEX.equals(AMEX)){
			AMEX();
		}

		if(PaymenttypeDISCOVER.equals(DISCOVER)){
			DISCOVER();
		}
		if(PaymenttypeVISA.equals(VISA)){
			VISA();
		}
		
		
		if(PaymenttypeMASTERCARD.equals(MASTERCARD)){
			MASTERCARD();
		}
	}*/	
		String purchageordernumber = getParameter(mapInputParameters,PO);
		String paymenttype = getParameter(mapInputParameters,Paymenttype);
		String nameoncard=getParameter(mapInputParameters,Nameoncard);
		String cardnumber=getParameter(mapInputParameters,Cardnumber);
		String expirymonth=getParameter(mapInputParameters,Expirymonth);
		String expiryyear=getParameter(mapInputParameters,Expiryyear);
		String cvv=getParameter(mapInputParameters,cardverificationnumber);
		
	/*private void DISCOVER() throws TestException {
		sonnysSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.ID, objectMap.getTestProperty(PROPERTY_PONUMBERID), purchageordernumber, "po");
		sonnysSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.ID, objectMap.getTestProperty(PROPERTY_NAMEONCARDID), nameoncard, "nameoncard");
		long num2 = new Long(cardnumber);
		sonnysSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.XPATH, objectMap.getTestProperty(PROPERTY_CARDNUMBERXPATH), num2, "cardnumber");
		sonnysSeleniumHandler.waitForAjaxToLoad();
		sonnysSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.ID, objectMap.getTestProperty(PROPERTY_EXPIRYMONTHID), expirymonth, "Expirymonth");
		sonnysSeleniumHandler.waitForAjaxToLoad();
		sonnysSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.ID, objectMap.getTestProperty(PROPERTY_EXPIRYYEARID), expiryyear, "Expiryyear");
		sonnysSeleniumHandler.waitForAjaxToLoad();

		sonnysSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.ID, objectMap.getTestProperty(PROPERTY_CARDCVVID), cvv, "cvv");
		
	}
	private void VISA() throws TestException {
		sonnysSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.ID, objectMap.getTestProperty(PROPERTY_PONUMBERID), purchageordernumber, "po");
		sonnysSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.ID, objectMap.getTestProperty(PROPERTY_NAMEONCARDID), nameoncard, "nameoncard");
		long num2 = new Long(cardnumber);
		sonnysSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.XPATH, objectMap.getTestProperty(PROPERTY_CARDNUMBERXPATH), num2, "cardnumber");
		sonnysSeleniumHandler.waitForAjaxToLoad();
		sonnysSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.ID, objectMap.getTestProperty(PROPERTY_EXPIRYMONTHID), expirymonth, "Expirymonth");
		sonnysSeleniumHandler.waitForAjaxToLoad();
		sonnysSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.ID, objectMap.getTestProperty(PROPERTY_EXPIRYYEARID), expiryyear, "Expiryyear");
		sonnysSeleniumHandler.waitForAjaxToLoad();

		sonnysSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.ID, objectMap.getTestProperty(PROPERTY_CARDCVVID), cvv, "cvv");

		
	}
	private void MASTERCARD() throws TestException {
		sonnysSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.ID, objectMap.getTestProperty(PROPERTY_PONUMBERID), purchageordernumber, "po");
		sonnysSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.ID, objectMap.getTestProperty(PROPERTY_NAMEONCARDID), nameoncard, "nameoncard");
		long num2 = new Long(cardnumber);
		sonnysSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.XPATH, objectMap.getTestProperty(PROPERTY_CARDNUMBERXPATH), num2, "cardnumber");
		sonnysSeleniumHandler.waitForAjaxToLoad();
		sonnysSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.ID, objectMap.getTestProperty(PROPERTY_EXPIRYMONTHID), expirymonth, "Expirymonth");
		sonnysSeleniumHandler.waitForAjaxToLoad();
		sonnysSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.ID, objectMap.getTestProperty(PROPERTY_EXPIRYYEARID), expiryyear, "Expiryyear");
		sonnysSeleniumHandler.waitForAjaxToLoad();

		sonnysSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.ID, objectMap.getTestProperty(PROPERTY_CARDCVVID), cvv, "cvv");		
	}
	private void AMEX() throws TestException {*/
		sonnysSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.ID, objectMap.getTestProperty(PROPERTY_PONUMBERID), purchageordernumber, "po");
		sonnysSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.ID, objectMap.getTestProperty(PROPERTY_NAMEONCARDID), nameoncard, "nameoncard");
		long num2 = new Long(cardnumber);
		sonnysSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.XPATH, objectMap.getTestProperty(PROPERTY_CARDNUMBERXPATH), num2, "cardnumber");
		sonnysSeleniumHandler.waitForAjaxToLoad();
		int num3 = Integer.parseInt(expirymonth);
		sonnysSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.ID, objectMap.getTestProperty(PROPERTY_EXPIRYMONTHID), num3, "Expirymonth");
		sonnysSeleniumHandler.waitForAjaxToLoad();
		sonnysSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.ID, objectMap.getTestProperty(PROPERTY_EXPIRYYEARID), expiryyear, "Expiryyear");
		sonnysSeleniumHandler.waitForAjaxToLoad();
		sonnysSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.ID, objectMap.getTestProperty(PROPERTY_CARDCVVID), cvv, "cvv");

		
	}
	
		}