package com.sonnys.sonnysdirectAutomation.Application;

import org.apache.log4j.Logger;

import com.sonnys.sonnysdirectAutomation.common.utils.TestException;
import com.sonnys.sonnysdirectAutomation.webdriver.utils.WebDriverConstants;

public class SelectAddress extends Application {
	private static final Logger logger = Logger.getLogger(AddProduct.class.getSimpleName());
	private static final String PROPERTY_ADDRESSBOOK_BUTTON = "ADDRESSBOOKBUTTON";
	private static final String PROPERTY_SELECTADDRESSBOOK_BUTTON = "ADDRESSBOOKFROMPOPUP";
	private static final String PROPERTY_DELIVERYMETHODBUTTONID = "DELIVERYMETHODBUTTONID";
	

	

	public void execute() throws TestException {
		sonnysSeleniumHandler.jsClick(WebDriverConstants.Locators.XPATH,
				objectMap.getTestProperty(PROPERTY_ADDRESSBOOK_BUTTON), "SELECT ADDRESS");
		sonnysSeleniumHandler.jsClick(WebDriverConstants.Locators.XPATH,
				objectMap.getTestProperty(PROPERTY_SELECTADDRESSBOOK_BUTTON), "SELECTADDRESS from the popup");
		sonnysSeleniumHandler.waitForAjaxToLoad();	
		sonnysSeleniumHandler.jsClick(WebDriverConstants.Locators.ID,
				objectMap.getTestProperty(PROPERTY_DELIVERYMETHODBUTTONID), "deliveryMethodSubmit");
		sonnysSeleniumHandler.waitForAjaxToLoad();	

	}}
