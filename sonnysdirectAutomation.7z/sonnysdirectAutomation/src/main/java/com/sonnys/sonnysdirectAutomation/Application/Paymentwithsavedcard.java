package com.sonnys.sonnysdirectAutomation.Application;

import org.apache.log4j.Logger;

import com.sonnys.sonnysdirectAutomation.common.utils.TestException;
import com.sonnys.sonnysdirectAutomation.webdriver.utils.WebDriverConstants;

public class Paymentwithsavedcard  extends Application {

	private static final Logger logger = Logger.getLogger(AddProduct.class.getSimpleName());
	private static final String PROPERTY_SAVEDCARDPYAMENTXPATH = "SAVEDCARDPYAMENT";
	private static final String PROPERTY_SELECTSAVEDCARD="SELECTSAVEDCARD";
	private static final String PROPERTY_TERMSCHECKBOXID="TERMSCHECKBOXID";
	private static final String PROPERTY_PLACEORDERID="PLACEORDERID";
	
	private static final String PROPERTY_ORDERCONFIRMATIONMESSAGE="ORDERCONFIRMATIONMESSAGE";
	
	
	
	public void execute() throws TestException {

	sonnysSeleniumHandler.jsClick(WebDriverConstants.Locators.XPATH,
			objectMap.getTestProperty(PROPERTY_SAVEDCARDPYAMENTXPATH), "SELECT PAYMENT CARD");
	sonnysSeleniumHandler.waitForAjaxToLoad();
	sonnysSeleniumHandler.jsClick(WebDriverConstants.Locators.XPATH,
			objectMap.getTestProperty(PROPERTY_SELECTSAVEDCARD), "SELECT CARD");
	sonnysSeleniumHandler.waitForAjaxToLoad();

	sonnysSeleniumHandler.jsClick(WebDriverConstants.Locators.ID, objectMap.getTestProperty(PROPERTY_TERMSCHECKBOXID), "terms and conditions");

	sonnysSeleniumHandler.jsClick(WebDriverConstants.Locators.ID,
			objectMap.getTestProperty(PROPERTY_PLACEORDERID), "placeorder");
	String s=sonnysSeleniumHandler.findElement(WebDriverConstants.Locators.XPATH, objectMap.getTestProperty(PROPERTY_ORDERCONFIRMATIONMESSAGE), "order confermation message").getText();
	System.out.println(s);
	
	

		
			/*sonnysSeleniumHandler.jsClick(WebDriverConstants.Locators.XPATH,
					objectMap.getTestProperty(PROPERTY_SAVEDCARDPYAMENTXPATH), "SELECT PAYMENT CARD");*/
			/*sonnysSeleniumHandler.jsClick(WebDriverConstants.Locators.XPATH, objectMap.getTestProperty(PROPERTY_BUTTON_CHECKOUT),
					"Go to Cart Page");*/
		
	String s1=sonnysSeleniumHandler.findElement(WebDriverConstants.Locators.XPATH, objectMap.getTestProperty(PROPERTY_ORDERCONFIRMATIONMESSAGE), "order confirmation message").getText();
		System.out.println(s1);
		sonnysSeleniumHandler.waitForAjaxToLoad();
		}}