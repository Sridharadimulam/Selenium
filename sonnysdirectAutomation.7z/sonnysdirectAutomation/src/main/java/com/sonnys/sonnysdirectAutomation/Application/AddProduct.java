package com.sonnys.sonnysdirectAutomation.Application;

import org.apache.log4j.Logger;

import com.sonnys.sonnysdirectAutomation.common.utils.TestException;
import com.sonnys.sonnysdirectAutomation.webdriver.utils.WebDriverConstants;

public class AddProduct extends Application {
	private static final Logger logger = Logger.getLogger(AddProduct.class.getSimpleName());
	private static final String PROPERTY_ID_BUTTON_ADDTOBASKET = "ADDTOCARTBUTTONID";
	private static final String PROPERTY_BUTTON_CHECKOUT = "ADDTOCARTBUTTONPOPUPXPATH";

	public void execute() throws TestException {
		sonnysSeleniumHandler.jsClick(WebDriverConstants.Locators.ID,
				objectMap.getTestProperty(PROPERTY_ID_BUTTON_ADDTOBASKET), "ADD TO BASKET");
		sonnysSeleniumHandler.jsClick(WebDriverConstants.Locators.XPATH, objectMap.getTestProperty(PROPERTY_BUTTON_CHECKOUT),
				"Go to Cart Page");
	}
}