package com.sonnys.sonnysdirectAutomation.common.utils;

public class TestException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -61438951198430304L;
	private String imagePath=null;
	public TestException() {
		super();
	}	

	public TestException(String message, Throwable cause) {
		super(message, cause);
	}

	public TestException(String message) {
		super(message);
	}
	
	public TestException(String message,String FilePath) {
		super(message);
		this.imagePath =FilePath;
	}

	public String getImagePath() {
		return imagePath;
	}

	public TestException(Throwable cause) {
		super(cause);
	}

}
