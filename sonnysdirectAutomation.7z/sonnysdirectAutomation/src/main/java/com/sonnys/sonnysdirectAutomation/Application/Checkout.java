package com.sonnys.sonnysdirectAutomation.Application;

import org.apache.log4j.Logger;

import com.sonnys.sonnysdirectAutomation.common.utils.TestException;
import com.sonnys.sonnysdirectAutomation.webdriver.utils.WebDriverConstants;

public class Checkout extends Application{
	private static final Logger logger = Logger.getLogger(Checkout.class.getSimpleName());
	
	private static final String PROPERTY_CARTCHECKOUT="CARTCHECKOUT";
	public void execute() throws TestException {
		sonnysSeleniumHandler.jsClick(WebDriverConstants.Locators.XPATH, objectMap.getTestProperty(PROPERTY_CARTCHECKOUT), "checkout");
		
	}
	

}
