package FunctionalData;
 
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.TestException;



 

 
public class functionLibs {
	
	private final String JS_JQUERY_DEFINED = "return typeof window.jQuery != 'undefined';";
	private final String JS_JQUERY_INACTIVE = "return window.jQuery.active == 0;";
	private final String JS_DOCUMENT_READY = "return document.readyState == 'complete';"; 
               
	
		int WAIT_TIME = 60;
				int POLLING_TIME=1; 
				WebDriver obrw=null;
		 

                public Boolean elementExists(WebDriver obrw,By ele)
                {
                                boolean exists= true;
                               
                                try
                                {
                               
                                                boolean display=obrw.findElement(ele).isDisplayed();
                                                exists=display;
                                }
                                catch(Exception e)
                                {
                                                exists=false;
                               
                                }
                                return exists;
                               
                }
             
                		/*private boolean executeBooleanJavascript(String javascript) throws TestException {
                			try {
                			//	logger.info("executing javascript -->" + javascript);
                				boolean result = (Boolean) ((JavascriptExecutor) obrw).executeScript(javascript);
                				return result;
                			} catch (Exception e) {
                			//	String err_message = "executeBooleanJavascript on " + javascript + " failed with error " + e.getMessage();
                			//	throw new TestException("WebDriverException", ErrorCodes.JAVASCRIPT_ERROR, err_message, null);
                			}
                		} 
                	 

                public void waitForAjaxToLoad() throws TestException {
                    boolean ajaxLoaded;
                    int totalWaitTime = 0;
                    do {
                          ajaxLoaded = true;
                          wait(1);
                          boolean jQueryDefined = executeBooleanJavascript(JS_JQUERY_DEFINED);
                          boolean documentReady = executeBooleanJavascript(JS_DOCUMENT_READY);
                          if (jQueryDefined) {
                                ajaxLoaded &= executeBooleanJavascript(JS_JQUERY_INACTIVE);
                          }
                          if (ajaxLoaded && documentReady) {
                                break;
                          }
                          totalWaitTime = totalWaitTime + WebDriverConstants.Time.POLLING_TIME;
                    } while (totalWaitTime < WebDriverConstants.Time.WAIT_TIME);
                    if (!ajaxLoaded) {
                          String errMsg = "ajax not loaded even after waiting for " + WebDriverConstants.Time.WAIT_TIME
                                      + " seconds, please find the snapshot at location";
                          String screenShot = captureScreenShoot();
                          throw new TestException("WebDriverException", ErrorCodes.AJAX_NOT_LOADED, errMsg,screenShot);
                    }
              }*/

                /**
                 * Sometime it happens while automating the angular app, view gets loaded entirely but performing any action
                 * on that view fails the test. This could happen because angular $http calls are still pending in backend.
                 * We can have explicit wait in this way to ensure that angular has made all the $http calls.
                 * Wait until angular finishes the $http calls while loading the view
                 */
                public void waitForAngular(WebDriver driver) {
                    final String javaScriptToLoadAngular = "return document.readyState == 'complete';";
                    	
                    ExpectedCondition<Boolean> pendingHttpCallsCondition = new ExpectedCondition<Boolean>() {
                        public Boolean apply(WebDriver driver) {
                            return ((JavascriptExecutor) driver).executeScript(javaScriptToLoadAngular).equals(true);
                        }
                    };
                    WebDriverWait wait = new WebDriverWait(driver, 30);
                    wait.until(pendingHttpCallsCondition);
                }

                
              
                
}
