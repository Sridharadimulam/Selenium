package FunctionalData;

import java.awt.Robot;

import java.awt.event.KeyEvent;

import java.util.Set;

 

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.firefox.FirefoxDriver;

import org.testng.ITestClass;

import org.testng.ITestClassFinder;

import org.testng.ITestResult;

import org.testng.annotations.AfterMethod;

import org.testng.annotations.AfterSuite;

import org.testng.annotations.AfterTest;

import org.testng.annotations.BeforeSuite;

import org.testng.annotations.BeforeTest;

import org.testng.annotations.Test;

 

import com.aventstack.extentreports.ExtentReports;

import com.aventstack.extentreports.ExtentTest;

import com.aventstack.extentreports.Status;

import com.aventstack.extentreports.markuputils.ExtentColor;

import com.aventstack.extentreports.markuputils.MarkupHelper;

import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import com.aventstack.extentreports.reporter.configuration.ChartLocation;

import com.aventstack.extentreports.reporter.configuration.Theme;

 

public class BaseExtentReport {

 

                public static ExtentHtmlReporter htmlReporter;

                public static ExtentReports report;

                public static ExtentTest test;

                WebDriver obrw;

               

                ScreenRecording scrRecording=new ScreenRecording();

               

                public void starRec() throws Exception

                {

                               

                }

               

                @BeforeSuite

                public void setUp() throws Exception

                {

                                scrRecording.startRecord();

                               

                                htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir") +"/test-output/ResellerConsoleReport.html");

                                report = new ExtentReports();

                                report.attachReporter(htmlReporter);

                        

                                 /*report.setSystemInfo("OS", "Windows 10");

                                report.setSystemInfo("Host Name", "Techwave");

                                report.setSystemInfo("Environment", "QA");

                                report.setSystemInfo("User Name", "Pradeep Neelam");*/

                         

                        htmlReporter.config().setChartVisibilityOnOpen(true);

                        htmlReporter.config().setDocumentTitle("Techwave.net Reports");

                        htmlReporter.config().setReportName("Reseller Report");

                        htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);

                        htmlReporter.config().setTheme(Theme.DARK);

                }

               

                /*@BeforeSuite

                public void setUp(ITestClass result) throws Exception

                {

                                //scrRecording.startRecord();

                                htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir") +"/test-output/"+result.getClass()+".html");

                                report = new ExtentReports();

                                report.attachReporter(htmlReporter);

                        

                        htmlReporter.config().setChartVisibilityOnOpen(true);

                        htmlReporter.config().setDocumentTitle("Techwave.net Reports");

                        htmlReporter.config().setReportName("LifeSciences Report");

                        htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);

                        htmlReporter.config().setTheme(Theme.DARK);

                }*/

               

                @AfterMethod

                public void getResult(ITestResult result)

                {

                                if(result.getStatus() == ITestResult.FAILURE)

        {

            test.log(Status.FAIL, MarkupHelper.createLabel(result.getName()+" Test case FAILED due to below issues:", ExtentColor.RED));

            test.fail(result.getThrowable());

           

        }

        else if(result.getStatus() == ITestResult.SUCCESS)

        {

               //String screenShotPath=GetScreenShot.capture(driver,"ScreenshotName");

            test.log(Status.PASS, MarkupHelper.createLabel(result.getName()+" Test Case PASSED", ExtentColor.GREEN));

           

        }

        else

        {

            test.log(Status.SKIP, MarkupHelper.createLabel(result.getName()+" Test Case SKIPPED", ExtentColor.ORANGE));

            test.skip(result.getThrowable());

        }

                }

               

                @AfterSuite

    public void tearDown() throws Exception

    {

                                report.flush();

                                System.setProperty("webdriver.chrome.driver", "C:\\Users\\10366\\Downloads\\chromedriver_win32\\chromedriver.exe");

                                obrw=new ChromeDriver();

                                obrw.manage().window().maximize();

                                obrw.get("file:///D:/Selenium_Scripts/SamplejavaiMicron/test-output/ResellerConsoleReport.html#!");

                               

                                /*String parent = obrw.getWindowHandle();

        Robot r = new Robot();

        r.keyPress(KeyEvent.VK_CONTROL);

        r.keyPress(KeyEvent.VK_T);

        r.keyRelease(KeyEvent.VK_CONTROL);

        r.keyRelease(KeyEvent.VK_T);

        Thread.sleep(3000);

        Set<String> browsers = obrw.getWindowHandles();

        for (String i : browsers)

        {

            if (!i.equals(parent))

            {

                obrw.switchTo().window(i);

                obrw.get("file:///C:/Users/10840/Desktop/Projects/S4HanaLifeSciences/TestResults/");

       

            }

        }*/

 

                                /*Thread.sleep(1000);

                                EmailReportingTest eReports=new EmailReportingTest();

                                eReports.VirchowsReport();*/

                                Thread.sleep(5000);

                               

                                scrRecording.stopRecord();

    }

               

                               

                public void stopRec() throws Exception

                {

                                scrRecording.stopRecord();

                }

               

                               

}