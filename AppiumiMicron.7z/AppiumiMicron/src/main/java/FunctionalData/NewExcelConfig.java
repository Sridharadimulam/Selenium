package FunctionalData;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Iterator;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.yaml.snakeyaml.scanner.Constant;



public class NewExcelConfig {
	
	private static final String PathFile = "D:\\Selenium_Scripts\\SamplejavaiMicron\\src\\testData\\ResellerConsole TestData.xls";
	String WriteFile="D:\\Selenium_Scripts\\SamplejavaiMicron\\src\\TestResults\\Notefile.txt";
	
	// "D:\\Selenium_Scripts\\src\\testData\\ResellerConsole TestData.xls";
	Workbook wb;
	HSSFWorkbook wb1;                      
	Sheet sh;
	static HSSFSheet sh1;
	WebDriver obrw;
	
	public void readExcel(String filePath,String fileName,String SheetName) throws Exception
	{
		File file=new File(filePath+"\\"+fileName);
		FileInputStream fis=new FileInputStream(file);
		String fileExtn=fileName.substring(fileName.indexOf("."));
		if(fileExtn.equals(".xlsx"))
		{
			wb=new XSSFWorkbook(fis);
			
		}
		else if(fileExtn.equals(".xls"))
		{
			wb1=new HSSFWorkbook(fis);
		
		}
	}
	
	public String GetData(int shno,int row,int col)
	{
		sh=wb.getSheetAt(shno);
		String data=sh.getRow(row).getCell(col).getStringCellValue();
		return data;
		
	}
	public String GetData2(int shno,int row,int col)
	{
		sh1=wb1.getSheetAt(shno);
		String data=sh1.getRow(row).getCell(col).getStringCellValue();
		return data;
		
	}
	
	public String GetData1(int shno,int row,int col)
	{
		Cell cell = sh.getRow(row).getCell(col);
		FormulaEvaluator formulaEval = wb.getCreationHelper().createFormulaEvaluator();
		String value=formulaEval.evaluate(cell).formatAsString();
		return value;
		
	}
	
	public double GetData3(int shnum,int row1,int col1)
	{
		sh=wb.getSheetAt(shnum);
		double data1=(double) sh.getRow(row1).getCell(col1).getNumericCellValue();
		return data1;  
		
	} 
	
	
	public int rowCount(int shno)
	{
		 int rows=wb1.getSheetAt(shno).getLastRowNum();
		//rows=rows+1;
		return rows;
		
	}
	
	public int colCount(int shno)
	{
		/*sh=wb.getSheetAt(shno);
		int NoOfCells=0;
		Iterator<Row> RowItr=sh.rowIterator();
		if (RowItr.hasNext())
        {
            Row headerRow = (Row) RowItr.next();
            //get the number of cells in the header row
            NoOfCells = sh.getRow(shno).getPhysicalNumberOfCells();
        }*/
        //System.out.println("number of cells "+NoOfCells);
		sh1=wb1.getSheetAt(shno);
		int NoOfCells=sh1.getRow(shno).getLastCellNum();
		return NoOfCells;	
     
	}
	/*public int GetNumber(int shnum,int row,int col)
	{
		sh=wb.getSheetAt(shnum);
		int data1= (int) sh.getRow(row).getCell(col).getNumericCellValue();
		//String readnumber = data1.toString();
		//String val=String.valueOf(data1);
		return data1;
		
	}*/
	
	public void setCellData(String Result,  int RowNum, int ColNum) throws Exception	{

			try{

  			HSSFRow Row  = sh1.getRow(RowNum);
if(Row==null)
{
	Row=sh1.createRow(RowNum);
	
}
			//HSSFCell cell = Row.getCell(ColNum, Row.RETURN_BLANK_AS_NULL);
  			HSSFCell cell = Row.getCell(ColNum);
			//cell.setCellValue(Result);

			if (cell == null) {

				cell = Row.createCell(ColNum);

				cell.setCellValue(Result);

				} else {

					cell.setCellValue(Result);

			}


  // Constant variables Test Data path and Test Data file name

  				FileOutputStream fileOut = new FileOutputStream(PathFile);

  				wb1.write(fileOut);

//  				fileOut.flush();
//
//					fileOut.close();

				}catch(Exception e){

					throw (e);

			}
			

		}

	public void WriteNotepadFile(String WriteFile,String st)  throws IOException
	{
	//Create a file
		
	//File file = new File(WriteFile);
     //"D:\\Selenium_Scripts\\SamplejavaiMicron\\src\\TestResults\\Notefile.txt");             //(�user.dir�)+�\\src\\newFile.txt�);
	//file.createNewFile();

	//File Writer
	FileWriter fw = new FileWriter(WriteFile,true); 
	//BufferedWriter writer = new BufferedWriter(fw);

	fw.write(st);
	fw.write("\r\n");
    
	fw.close();
	}
	
	/* public void getscreenshot() throws Exception 
    {
		   WebDriver driver = new ChromeDriver();
            File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
         //The below method will save the screen shot in d drive with name "screenshot.png"
            FileUtils.copyFile(scrFile, new File("D:\\screenshot1.png"));
    } */
	
    public void getScreenShot(String fileName,WebDriver objbr ) throws IOException{
    	
        DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH-mm-ss"); 
        Date date = new Date();
        
        File scrFile = ((TakesScreenshot)objbr).getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(scrFile, new File("D:\\Selenium_Scripts\\SamplejavaiMicron\\src\\TestLogs\\"+ fileName +"_"+dateFormat.format(date)+".png"));  //dateFormat.format(date)
    }

}

	
	
