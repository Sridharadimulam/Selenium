package Appium.AppiumiMicron;

import java.net.MalformedURLException;
import java.util.concurrent.TimeUnit;

import org.apache.tools.ant.taskdefs.optional.ejb.IPlanetEjbc.EjbcException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.Test;

import FunctionalData.NewExcelConfig;
import UtilityLibrary.functionLibs;
import io.appium.java_client.MobileDriver; 

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;


public class ImicronLogin extends Login_PreRequisites
{
	NewExcelConfig nec=new NewExcelConfig();
	
	String ExcelPath="C:\\Users\\10366\\workspace\\AppiumiMicron\\src\\main\\java\\TestData\\";
	String FileName="iMicronMarketPlaceTestData.xlsx";
	//int SheetNo=0;
	String SheetName="MarketPlace";
    String str;
    String FBUrl;
    String FBConPage;
	
    //@Test
	public  void iMicronlogin() throws Exception 
    {
    	
    	  nec.readExcel(ExcelPath,FileName,SheetName);
    	  
		// TODO Auto-generated method stub
		  AndroidDriver<AndroidElement> obrw = CapabilitiesSetup();
		  obrw.findElement(By.id("com.techwave.imicron:id/edt_Email")).clear();
      	  obrw.findElement(By.id("com.techwave.imicron:id/edt_Email")).sendKeys(nec.GetData(0, 1, 0));
    	  obrw.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    	  obrw.findElement(By.id("com.techwave.imicron:id/edt_Password")).sendKeys(nec.GetData(0, 1, 1));
    	  obrw.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    	  obrw.findElement(By.id("com.techwave.imicron:id/btnLogin")).click();	
    	  obrw.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    	  
    	  System.out.println(obrw.findElement(By.id("com.techwave.imicron:id/toolbar_title")).getText());
    	  str=obrw.findElement(By.id("com.techwave.imicron:id/toolbar_title")).getText();
    	  //obrw.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    	  if (str.equals("Dashboard"))
    		  System.out.println("iMicron App Logged in Successfully");
    	  else
       		  System.out.println("iMicron App Login Unsuccessfully");	
    	  //com.techwave.imicron:id/toolbar_title 
    }
    
    @Test
    public void LoginFacebook() throws Exception
    {
    	  nec.readExcel(ExcelPath,FileName,SheetName);
    	  AndroidDriver<AndroidElement> obrw = CapabilitiesSetup();
    	  

    	  
    	  //Login Thru Facebook
    	  obrw.findElement(By.id("com.techwave.imicron:id/llFB")).click();	
    	  obrw.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
    	  
    	 // wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[4]/div[1]/span[2]/input[@ type='checkbox' and @ng-checked='priceType.isChecked']")));    
    	 // obrw.findElement(By.xpath("//div[4]/div[1]/span[2]/input[@ type='checkbox' and @ng-checked='priceType.isChecked']")).click();
          
    	  //if (obrw.findElement(By.xpath("//div[4]/div[1]/span[2]/input[@ type='checkbox' and @ng-checked='priceType.isChecked']")).isDisplayed())
    	  
    	  if (obrw.findElement(By.xpath("//android.widget.EditText[@text='https://m.facebook.com']")).isDisplayed())  // && (obrw.findElement(By.xpath("//android.view.ViewText[@index=0]")).getText().equals("facebook")))   //@text='facebook' @enabled=true,    (FBUrl.equals("https://m.facebook.com"))
   	       {
    		  System.out.println("Successfully launch first the FB Login Page");
    		 
    		  //wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//div[5]/span[@ng-model='filter.priceType' and @ng-click='advFilter(filter.priceType)']"))));
    		  //wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//android.view.View[@text='facebook']"))));
    		  obrw.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		      if (obrw.findElement(By.xpath("//android.view.View[@enabled='true' and @index=1]")).isDisplayed())  //index=0 and @text='facebook'
		      {
		     
		          obrw.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);//android.widget.EditText 
		    	  //wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//android.widget.EditText[@index=0 and @text='Email address or phone number']"))));
		          obrw.findElement(By.xpath("//android.widget.EditText[@index=0 and @resource-id='m_login_email']")).clear();    	
		         
		          obrw.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);//android.widget.EditText
		          obrw.findElement(By.xpath("//android.widget.EditText[@index=0 and @resource-id='m_login_email']")).sendKeys(nec.GetData(0, 1, 2));	 //m_login_email    nec.GetData(0, 1, 2)
			  
		           obrw.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			    
			      //obrw.findElement(By.xpath("//android.widget.EditText[@text='Facebook password']")).clear();
		          //wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//android.widget.EditText[@index=1 and @text='Facebook password']"))));  
			      obrw.findElement(By.xpath("//android.widget.EditText[@index=1 and @text='Facebook password']")).sendKeys(nec.GetData(0, 1, 3));		    //nec.GetData(0, 1, 3)   resource-id='m_login_password'
			      
			      obrw.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			      //wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//android.widget.Button[@index=0 and text='Log In']"))));            //@resource-id='u_0_5'
			      obrw.findElement(By.xpath("//android.widget.Button[@index=0 and @resource-id='u_0_5']")).click();
			   
			      obrw.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			      //wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//android.view.View[@resource-id='m-future-page-header-title']"))));
			      FBConPage=obrw.findElement(By.xpath("//android.view.View[@resource-id='m-future-page-header-title']")).getText();
			      if (FBConPage.equals("Confirm login"))
			      {
				    	System.out.println("Successfully Launch the Confirmation Page");
				    	obrw.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				    	//wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//android.widget.Button[@text='Continue']"))));
						obrw.findElement(By.xpath("//android.widget.Button[@text='Continue']")).click();
						
						obrw.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
						//wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.id("com.techwave.imicron:id/toolbar_title"))));
						 System.out.println(obrw.findElement(By.id("com.techwave.imicron:id/toolbar_title")).getText());
						 str=obrw.findElement(By.id("com.techwave.imicron:id/toolbar_title")).getText();
						 //obrw.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
					     if (str.equals("Dashboard"))
							System.out.println("iMicron App Logged in thru Facebook Successfully");
						 else
						    System.out.println("iMicron App Login Unsuccessfully thru Facebook");
								    	  
			      }
	    	  }

    	      else //if (obrw.findElement(By.xpath("//android.widget.EditText[@text='https://m.facebook.com']")).getText().equals("https://m.facebook.com") && obrw.findElement(By.xpath("//android.view.ViewText[@index=1]")).getText().equals("Confirm login"))
    	      {  
    		      System.out.println("Successfully loading second the FB Login Page");
    		
    	  //obrw.findElement(By.xpath("//android.view.View[@text='facebook']")).isEnabled();
    	    // System.out.println(obrw.findElement(By.xpath("//android.view.View[@text='Confirm login']")).getTagName());  //(obrw.findElement(By.xpath("//android.widget.EditText[@text='https://m.facebook.com']")).getText().equals("https://m.facebook.com"))
    	     //if (obrw.findElement(By.xpath("//android.view.View[@index=1]")).getText().equals("Confirm login")) //(obrw.findElement(By.xpath("//android.view.View[@text='Confirm login']")).isDisplayed())
	         //{
				  System.out.println("Successfully Launch the Confirmation Page");
				  obrw.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				  //wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.xpath("//android.widget.Button[@text='Continue']"))));
				  obrw.findElement(By.xpath("//android.widget.Button[@text='Continue']")).click();
				  
				  obrw.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				  //wait.until(ExpectedConditions.visibilityOf(obrw.findElement(By.id("com.techwave.imicron:id/toolbar_title"))));
				  System.out.println(obrw.findElement(By.id("com.techwave.imicron:id/toolbar_title")).getText());
				  str=obrw.findElement(By.id("com.techwave.imicron:id/toolbar_title")).getText();
				     //obrw.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				  if (str.equals("Dashboard"))
					System.out.println("iMicron App Logged in thru Facebook Successfully");
				  else
				    System.out.println("iMicron App Login Unsuccessfully thru Facebook");
	         // } 
    	  
    	      }
      }//if facebook login
    }   
}  //class

    	  //@resource-id='com.android.chrome:id/url_bar'
    	  //if (obrw.findElement(By.xpath("//android.widget.EditText[@text='https://m.facebook.com']")).getText().equals("https://m.facebook.com") && obrw.findElement(By.xpath("//android.view.View[@text='Confirm login']")).getText().equals("Confirm login"))
    	  
    	  //if (obrw.findElement(By.xpath("//android.widget.EditText[@resource-id='com.android.chrome:id/url_bar']")).getText().equals("https://m.facebook.com") && obrw.findElement(By.xpath("//android.view.View[@resource-id='m-future-page-header-title']")).getText().equals("Confirm login"))  //
    	 
    	  
    	  //obrw.findElement(By.xpath("//android.widget.EditText[@resource-id='com.android.chrome:id/url_bar']")).getText().equals("https://m.facebook.com")
    	 
    	  
		    	  
    	  // logout   ----com.techwave.imicron:id/action_item5
    	  /*com.techwave.imicron:id/btnLogout
    	  com.techwave.imicron:id/toolbar_title ---More getText()
    	  android:id/button1 ---Yes
    	  android:id/button2 ---No
    	  android.widget.FrameLayout  ---iMicron Login page
    	  */
    	  
    	  //Login Thru Google+
    	  /*obrw.findElement(By.id("com.techwave.imicron:id/llGP")).click();	
    	  obrw.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    	  
    	  //Remember me 
    	  obrw.findElement(By.id("com.techwave.imicron:id/chk_rememberMe")).click();	
    	  obrw.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);*/
    	  
  
   /* public void iMicronDashboard() throws Exception
    {
    	
    }*/

	





