package Appium.AppiumiMicron;

import java.io.File;

import java.net.URL;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.remote.CapabilityType;

import org.openqa.selenium.remote.DesiredCapabilities;

import org.testng.annotations.Test;

 

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

 

public class Login_PreRequisites 
{
	 //static WebDriver obrw;     
    @Test
    public AndroidDriver<AndroidElement> CapabilitiesSetup() throws Exception       //AndroidDriver<AndroidElement> is method Return type
    {
                                
       File fs = new File("C:\\Users\\10366\\Documents\\My Received Files\\app-release.apk");
       // File f = new File(fs,"ApiDemos-debug.apk");

       // Created object of DesiredCapabilities class.
       DesiredCapabilities capabilities = new DesiredCapabilities();

       //capabilities.setCapability("deviceName", "Nexus 6 API 23:5554");
       capabilities.setCapability("deviceName", "b4fee09f");
 
       // Set browserName desired capability. It's Android in our case here.
       capabilities.setCapability("browserName", "Android");

       // Set android platformVersion desired capability. Set your emulator's android version.
       capabilities.setCapability("platformVersion", "5.1");

       // Set android platformName desired capability. It's Android in our case here.
       capabilities.setCapability("platformName", "Android");
 
	   capabilities.setCapability("app", fs.getAbsolutePath());
	   capabilities.setCapability("app-package", "com.techwave.imicron");                  
	   capabilities.setCapability("app-activity", "com.techwave.imicron.SplashScreenActivity "); 
	   
	   //capabilities.setCapability("fb-package", "com.android.chrome");
	   //com.android.chrome
	   
	   
	   
	   //AndroidDriver<AndroidElement> driver = new AndroidDriver<AndroidElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities); 
	   AndroidDriver<AndroidElement> driver = new AndroidDriver<AndroidElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities); 

       //obrw = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities); // appium login

      driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
       
       return driver;
    }
   
    }


              
