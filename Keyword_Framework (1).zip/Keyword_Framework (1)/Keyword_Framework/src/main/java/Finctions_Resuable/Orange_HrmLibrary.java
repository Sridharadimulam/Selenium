package Finctions_Resuable;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
public class Orange_HrmLibrary  {
//global variables declaration
public static WebDriver driver;
public static String url="http://orangehrm.qedgetech.com/symfony/web/index.php/auth/login";
public static String uid="Admin";
public static String pwd="admin";
public static String Expval,Actval;
public static String fn,ln;
public static Properties p;
public static FileInputStream fi;
/*
 * Module Name:Verify launch Application
 * Designed By:Ranggaa
 * Designed On:08009/17
 * 
 */
public boolean Verify_LaunchApp(String url)  {
Expval="LOGIN";
//System.setProperty("webdriver.chrome.driver", "D:/chromedriver.exe");
driver=new ChromeDriver();
driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
driver.manage().window().maximize();
driver.get(url);
Actval=driver.findElement(By.id("btnLogin")).getAttribute("value");
			try {
Assert.assertEquals(Actval, Expval, "Application not launched Successfully");
	} catch (AssertionError e) {
System.out.println(e.getMessage());
		return false;
		}
	return true;
	}
/*
 * Module Name:Verify Admin Login
 * Designed By:Ranggaa
 * Designed On:08009/17
 * 
 */
public boolean Verify_adminLogin(String uid, String pwd) throws IOException{
p=new Properties();
fi=new FileInputStream("D:\\Mrng_Framework\\Keyword_Framework\\src\\main\\java\\Config\\OrangeHRM.properties");
p.load(fi);
Expval="Welcome Admin";
driver.findElement(By.xpath(p.getProperty("User"))).sendKeys(uid);
driver.findElement(By.xpath(p.getProperty("Pass"))).sendKeys(pwd);
driver.findElement(By.xpath(p.getProperty("LoginBtn"))).click();
Actval=driver.findElement(By.linkText("Welcome Admin")).getText();
		try {
Assert.assertEquals(Actval, Expval,"Admin login Failed");
} catch (AssertionError e) {
System.out.println(e.getMessage());
return false;
}return true;
		}
/*
 * Module Name:Verify Admin Logout
 * Designed By:Ranggaa
 * Designed On:08009/17
 * 
 */
public boolean  Verify_AdminLogout() throws InterruptedException, IOException{
Expval="LOGIN";
boolean b=false;
driver.findElement(By.xpath(p.getProperty("welcome"))).click();
Thread.sleep(4000);
driver.findElement(By.xpath(p.getProperty("logout"))).click();
Thread.sleep(4000);
Actval=driver.findElement(By.id("btnLogin")).getAttribute("value");
	try {
Assert.assertEquals(Actval, Expval,"Admin logout Failed");
		} catch (AssertionError e) {
		return false;
		}
	return true;
			}	
/*
 * Module Name:Verify Close browser
 * Designed By:Ranggaa
 * Designed On:08009/17
 * 
 */
public void Verify_closeApp(){
driver.quit();
}
/*
 * Module Name:Verify Emp Creation
 * Designed By:Ranggaa
 * Designed On:08009/17
 * 
 */
public boolean Verify_empreg(String fn,String ln,String eid) throws IOException{
Expval=fn+" "+ln;
driver.findElement(By.xpath(p.getProperty("Pim"))).click();
driver.findElement(By.xpath(p.getProperty("Btnadd"))).click();
driver.findElement(By.xpath(p.getProperty("FirstName"))).sendKeys(fn);
driver.findElement(By.xpath(p.getProperty("LastName"))).sendKeys(ln);
driver.findElement(By.xpath(p.getProperty("Eid"))).sendKeys(eid);
driver.findElement(By.xpath(p.getProperty("SaveButton"))).click();
Actval=driver.findElement(By.xpath("html/body/div[1]/div[3]/div/div[1]/div/h1")).getText();
try {
Assert.assertEquals(Actval, Expval,"New Employee Registration Failed");	
} catch (AssertionError e) {
System.out.println(e.getMessage());
return false;
}
return true;
}
/*
 * Module Name:Verify User Creation
 * Designed By:Ranggaa
 * Designed On:08009/17
 * 
 */
public boolean Verify_userreg(String empname,String un,String pwd,String cpwd) throws InterruptedException, IOException
	{
System.out.println("user Register ");
Actions ac=new Actions(driver);
WebElement ad=driver.findElement(By.xpath(p.getProperty("Admin")));
ac.moveToElement(ad).click().perform();
Thread.sleep(3000);
WebElement um=driver.findElement(By.xpath(p.getProperty("uman")));
ac.moveToElement(um).click().perform();
Thread.sleep(3000);
WebElement u=driver.findElement(By.xpath(p.getProperty("userm")));
ac.moveToElement(u).click().perform();
Thread.sleep(5000);
driver.findElement(By.xpath(p.getProperty("add"))).click();
Thread.sleep(2000);
driver.findElement(By.xpath(p.getProperty("ename"))).sendKeys(empname);
driver.findElement(By.xpath(p.getProperty("user"))).sendKeys(un);
driver.findElement(By.xpath(p.getProperty("pwd"))).sendKeys(pwd);
driver.findElement(By.xpath(p.getProperty("cpwd"))).sendKeys(cpwd);
driver.findElement(By.xpath(p.getProperty("save"))).click();
Thread.sleep(5000);
Expval =pwd;
Actval= cpwd;
try {
Assert.assertEquals(Actval, Expval,"User Registration Failed");
} catch (AssertionError e) {
return false;
}
return true;
}




//method for user login
public boolean userlogin(String un,String pwd){
driver.findElement(By.id("txtUsername")).sendKeys(un);
driver.findElement(By.id("txtPassword")).sendKeys(pwd);
driver.findElement(By.id("btnLogin")).click();
Expval="Leave";
Actval=driver.findElement(By.linkText("Leave")).getText();
	try {
Assert.assertEquals(Actval, Expval,"User Login Unsuccessfull");	
} catch (AssertionError e) {
return false;
	}
	return true;
		}
}
