package OrangeHRM_Maintest;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;
import Finctions_Resuable.Orange_HrmLibrary;
public class AppTest {
@Test
public void keyworddriventest() throws IOException, InterruptedException{
	//initializing logger
Logger log  = Logger.getLogger("keywordDrivenTest");
PropertyConfigurator.configure("D:\\Mrng_Framework\\Keyword_Framework\\src\\main\\java\\Config\\Log4j.properties");
	String kwxlpath,tcexeflg,tcid,tstcid,keyword;
	String tcres="pass";
	boolean kwres = false;
	int testcasecount,teststepcount;
kwxlpath="D:\\Mrng_Framework\\Keyword_Framework\\src\\main\\java\\DataEngine\\keywords.xlsx";
	log.info("excel accesssed");
	//accessing libary functions into driver script
	Orange_HrmLibrary hrm=new Orange_HrmLibrary();
   log.info("libary functions accessed");
	FileInputStream fi=new FileInputStream(kwxlpath);
	XSSFWorkbook wb=new XSSFWorkbook(fi);
	XSSFSheet ws1=wb.getSheet("TestCases");
	XSSFSheet ws2=wb.getSheet("TestSteps");
	//counting no of rows in both sheets
	testcasecount=ws1.getLastRowNum();
	teststepcount=ws2.getLastRowNum();
	System.out.println(testcasecount);
	System.out.println(teststepcount);
	//iterate Testcases sheet
	log.info("iterate sheet1 rows");
	for(int i=1;i<=testcasecount;i++)
	{
		//reading Execute column
		log.info("storing 3 rd column");
	tcexeflg=ws1.getRow(i).getCell(2).getStringCellValue();
		System.out.println(tcexeflg);
		//ignore case sensitive
		if(tcexeflg.equalsIgnoreCase("Y"))
		{
	//reading Testcaseid column
	tcid=ws1.getRow(i).getCell(0).getStringCellValue();
	System.out.println(tcid);
	//iterate TestSteps  sheet
for(int j=1;j<=teststepcount;j++)
		{
		//reading Testcase id from second sheet
tstcid=ws2.getRow(j).getCell(0).getStringCellValue();
	System.out.println(tstcid);
if(tcid.equalsIgnoreCase(tstcid))
	{
////reading keywod column from second sheet
keyword=ws2.getRow(j).getCell(4).getStringCellValue();
System.out.println(keyword);
switch (keyword.toUpperCase()) 
{
case "LAUNCHAPP":
kwres=hrm.Verify_LaunchApp(hrm.url);
break;
case "ADMINLOGIN":
kwres=hrm.Verify_adminLogin(hrm.uid, hrm.pwd);
break;
case "LOGOUT":
kwres=hrm.Verify_AdminLogout();
	hrm.Verify_closeApp();
break;
case "USERREG":
kwres=hrm.Verify_userreg("Ankit Tester", "test56", "calu1234", "calu1234");
break;
case "EMPREG":
kwres=hrm.Verify_empreg("rita123", "meta123", "5454");
break;
case "USERLOGIN":
kwres=hrm.userlogin("test765","demo123678");
break;
	}
if(kwres==true){
ws2.getRow(j).createCell(3).setCellValue("Pass");
tcres="pass";
			}else {
ws2.getRow(j).createCell(3).setCellValue("Fail");
tcres="Fail";
		}
					
ws1.getRow(i).createCell(3).setCellValue(tcres);
				}
			}
		}else
		{
ws1.getRow(i).createCell(3).setCellValue("Blocked");
		}
	}
	
FileOutputStream fo=new FileOutputStream("D:\\Mrng_Framework\\Keyword_Framework\\src\\main\\java\\DataEngine\\Results.xlsx");
wb.write(fo);
wb.close();
}
}
		
















