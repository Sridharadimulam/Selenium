package com.Grice.qa.Testcases;

public class Homepage {

	public  void test(){
		System.out.println("hi home");
	}
}
