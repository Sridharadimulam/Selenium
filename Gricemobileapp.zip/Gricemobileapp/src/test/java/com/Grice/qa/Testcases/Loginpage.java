package com.Grice.qa.Testcases;

public class Loginpage {
	public Homepage h;
	public static void main (String []args){
		
		System.out.println("hi login");
	}
	
}
