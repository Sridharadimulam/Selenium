package com.Grice.qa.pages;

import java.util.logging.Logger;

import in.co.gauravtiwari.voice.client.VoiceAutomationClient;
import in.co.gauravtiwari.voice.clientresources.ClientOperationException;
import in.co.gauravtiwari.voice.clientresources.Voice;
import in.co.gauravtiwari.voice.design.Language;

public class voicetest {
	public static void texttospeachtest(){
		//public final Logger log=Logger.getLogger(voicetest.class);
	System.setProperty("VoiceAutomationserverEndpoint","http://<voiceServerIp>:9090/");
	System.setProperty("VoiceRsskey","<VoiceRSSAPIKey>");
	/*	try{
		Voice voice=new Voice( text: "Alexa ! Play Beatles",Language.ENGLISH_INDIA);
		VoiceAutomationClient voiceutomationClient=new VoiceAutomationClient();
		VoiceAutomationClient.load(voice);
		VoiceAutomationClient.play(voice);
	}
	catch(ClientOperationException e)
	{
		e.printStackTrace();
	}catch(Exception ex)
	{
		ex.printStackTrace();
	}*/
	}

}
