package hu.euronics.euronicsautomation.webdriver.utils;

public interface Handler {

	void setBrowser();

	void setDesiredCapabilities();

	void setDriversPath();

	void setUrl();

}
