package hu.euronics.euronicsautomation.application;

import hu.euronics.euronicsautomation.common.utils.TestException;
import hu.euronics.euronicsautomation.webdriver.utils.WebDriverConstants;

public class OnlinePayment extends Application {
	private static final String PROPERTY_TEXTBOX_CARDNUMBER = "CARD_NUMBER";
	private static final String PROPERTY_TEXTBOX_CARDNAME = "CARD_NAME";
	private static final String PROPERTY_TEXTBOX_EXPIRYMONTH = "EXPIRY_MONTH";
	private static final String PROPERTY_TEXTBOX_EXPIRYYEAR = "EXPIRY_YEAR";
	private static final String PROPERTY_TEXTBOX_BANKNAME = "BANK_NAME";
	private static final String PROPERTY_TEXTBOX_CODE = "VALID_CODE";
	private static final String PROPERTY_TEXTBOX_BUYERNAME = "BUYER_NAME";
	private static final String PROPERTY_IFRAME = "IFRAME";
	private static final String HTMLTAG_FIELD = "FIELD";
	
	
	public void execute() throws TestException {

		String cardNumber = getParameter(mapInputParameters, CARDNUMBER);
		String cardName = getParameter(mapInputParameters, CARDNAME);
		String expiryMonth = getParameter(mapInputParameters, EXPIRYMONTH);
		String expiryYear = getParameter(mapInputParameters, EXPIRYYEAR);
		String bankName = getParameter(mapInputParameters, BANKNAME);
		String validCode = getParameter(mapInputParameters, VALIDCODE);
		String buyerName = getParameter(mapInputParameters, BUYERNAME);
		
		euronicsSeleniumHandler.waitForAjaxToLoad();
		euronicsSeleniumHandler.waitForAjaxToLoad();
		euronicsSeleniumHandler.waitForAjaxToLoad();
		euronicsSeleniumHandler.switchToChildFrame(WebDriverConstants.Locators.ID, objectMap.getTestProperty(HTMLTAG_FIELD),
				WebDriverConstants.Locators.TAGNAME, objectMap.getTestProperty(PROPERTY_IFRAME),
				"paypal iframe");
		euronicsSeleniumHandler.setListBoxItem( WebDriverConstants.Locators.ID,
				objectMap.getTestProperty(PROPERTY_TEXTBOX_CARDNUMBER),cardNumber,"enter card number");
		euronicsSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.XPATH,
				objectMap.getTestProperty(PROPERTY_TEXTBOX_CARDNAME), cardName, "Enter name on Card");
		
		euronicsSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.XPATH,
				objectMap.getTestProperty(PROPERTY_TEXTBOX_EXPIRYMONTH), expiryMonth, "enter expiry date");
		euronicsSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.XPATH,
				objectMap.getTestProperty(PROPERTY_TEXTBOX_EXPIRYYEAR), expiryYear, "enter expiry date");
		euronicsSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.XPATH,
				objectMap.getTestProperty(PROPERTY_TEXTBOX_BANKNAME), bankName, "enter bank name ");
		
		euronicsSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.XPATH,
				objectMap.getTestProperty(PROPERTY_TEXTBOX_CODE), validCode, "valid code");
		euronicsSeleniumHandler.jsSendKeys(WebDriverConstants.Locators.XPATH,
				objectMap.getTestProperty(PROPERTY_TEXTBOX_BUYERNAME), buyerName, "buyer name");
		
		
		/*euronicsSeleniumHandler.jsClick(WebDriverConstants.Locators.ID, objectMap.getTestProperty(PROPERTY_BUTTON_SUBMIT_ID),
				"Submit Delivery method");*/
		
	}
}
